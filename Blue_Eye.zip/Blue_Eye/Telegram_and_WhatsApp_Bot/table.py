import pandas as pd
import os
from flask import Flask, render_template_string, send_file, request
import smtplib
from email.message import EmailMessage
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, letter
from reportlab.platypus import PageBreak


app = Flask(__name__)



def fetch_weather_data(lat, lon, timestamp):
    url = f"https://api.openweathermap.org/data/2.5/weather?lat=12.933513&lon=77.692435&appid=5da96c791203992bab614388a4cf3bec"
    try:
        response = requests.get(url)
        data = response.json()
        humidity = data.get('main', {}).get('humidity', None)
        pressure = data.get('main', {}).get('pressure', None)
        temp = data.get('main', {}).get('temp', None)
        feels_like = data.get('main', {}).get('feels_like', None)
        temp_min = data.get('main', {}).get('temp_min', None)
        temp_max = data.get('main', {}).get('temp_max', None)
        sea_level = data.get('main', {}).get('sea_level', None)
        return {
            'humidity': humidity,
            'pressure': pressure,
            'temp': temp,
            'feels_like': feels_like,
            'temp_min': temp_min,
            'temp_max': temp_max,
            'sea_level': sea_level
        }
    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None



def get_rainfall_between_range():
    try:
        file_path = r'E:\SIH2024\Map\Telegram_bot\weather_data_corrected.xlsx'
        df = pd.read_excel(file_path, engine='openpyxl')
        # print(df['rain_last_6hrs'])
        return df['rain_last_6hrs']
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return 0


def process_telemetry_data(file_path):
    try:
        df = pd.read_excel(file_path, engine='openpyxl')
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return None

    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

    df['water_level_anomaly'] = False
    df['battery_level_anomaly'] = False
    df['dwlr_depth_anomaly'] = False
    df['well_depth_anomaly'] = False
    df['temp_anomaly'] = False
    df['Notify'] = False
    water_anomaly = False

    for idx, row in df.iterrows():
        water_level = row['water_level']
        battery = row['battery']
        DWLR_depth = row['DWLR_depth']
        well_depth = row['well_depth']
        water_temperature = row['water_temperature']

        water_level_anomaly = False
        if not pd.isna(water_level):
            water_levels = df[df['telemetry_uid'] == row['telemetry_uid']]['water_level'].dropna()
            water_level_indices = water_levels.index.tolist()
            current_index = water_level_indices.index(row.name)  
            if current_index > 0:
                recent = water_levels.iloc[current_index]
                historical = water_levels.iloc[current_index - 1]
                diff = abs(recent - historical)
                if diff >= 0.35:
                    if any(diff > get_rainfall_between_range()):
                        water_anomaly = True
                    else:
                        water_anomaly = False
                water_level_anomaly = diff >= 0.35

                    

        battery_level_anomaly = False
        if not pd.isna(battery):
            battery_level_anomaly = not (3.25 <= battery <= 4)

        dwlr_depth_anomaly = False
        if not pd.isna(DWLR_depth) and abs(water_level) > DWLR_depth:
            dwlr_depth_anomaly = True

        well_depth_anomaly = False
        if not pd.isna(well_depth) and (DWLR_depth > well_depth or abs(water_level) > well_depth):
            well_depth_anomaly = True

        temp_anomaly = False
        if not pd.isna(water_temperature):
            temp_anomaly = not (15 <= water_temperature <= 35)

        notify = any([water_level_anomaly, battery_level_anomaly, dwlr_depth_anomaly, well_depth_anomaly, temp_anomaly])

        df.at[idx, 'water_level_anomaly'] = water_level_anomaly
        df.at[idx, 'battery_level_anomaly'] = battery_level_anomaly
        df.at[idx, 'dwlr_depth_anomaly'] = dwlr_depth_anomaly
        df.at[idx, 'well_depth_anomaly'] = well_depth_anomaly
        df.at[idx, 'temp_anomaly'] = temp_anomaly
        df.at[idx, 'Notify'] = notify

    column_order = [
        'telemetry_uid', 'state', 'district', 'tahsil', 'block', 'village', 'latitude', 'longitude',
        'timestamp', 'battery', 'water_temperature', 'water_level', 'DWLR_depth', 'well_depth',
        'water_level_anomaly', 'battery_level_anomaly', 'dwlr_depth_anomaly', 'well_depth_anomaly',
        'temp_anomaly', 'Notify'
    ]

    df = df[column_order]
    return df

def data_to_html(data):
    html = '''
    <html>
    <head>
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }
            table, th, td {
                border: 1px solid black;
            }
            th, td {
                padding: 8px;
                text-align: center;
            }
            th {
                background-color: #4CAF50;
                color: white;
            }
            td.alert {
                background-color: #FFCCCC;  /* Light Red */
                color: black;
            }
            td.normal {
                background-color: #CCFFCC;  /* Light Green */
                color: black;
            }
        </style>
    </head>
    <body>
        <h1>Processed Telemetry Data</h1>
        <table>
            <thead>
                <tr>
                    <th>Telemetry UID</th>
                    <th>State</th>
                    <th>District</th>
                    <th>Tahsil</th>
                    <th>Block</th>
                    <th>Village</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Timestamp</th>
                    <th>Battery</th>
                    <th>Water Temperature</th>
                    <th>Water Level</th>
                    <th>DWLR Depth</th>
                    <th>Well Depth</th>
                    <th>Water Level Anomaly</th>
                    <th>Battery Level Anomaly</th>
                    <th>DWLR Depth Anomaly</th>
                    <th>Well Depth Anomaly</th>
                    <th>Temp Anomaly</th>
                    <th>Notify</th>
                </tr>
            </thead>
            <tbody>
    '''
    for _, row in data.iterrows():
        html += '<tr>'
        for col in data.columns:
            value = row[col]
            class_name = ""
            if col.endswith('_anomaly') or col == 'Notify':
                if value:
                    value = "Alert"
                    class_name = "alert"
                else:
                    value = "Normal"
                    class_name = "normal"

            html += f'<td class="{class_name}">{value}</td>'
        html += '</tr>'
    html += '''
            </tbody>
        </table>
    </body>
    </html>
    '''
    return html



@app.route('/')
def display_table():
    file_path = r'C:\Users\MOHANAPRASAD\Downloads\Maha.xlsx'
    processed_data = process_telemetry_data(file_path)
    if processed_data is not None:
        return render_template_string(data_to_html(processed_data))
    else:
        return "Error processing data"

@app.route('/download')
def download_file():
    file_path = r'C:\Users\MOHANAPRASAD\Downloads\Maha.xlsx'
    
    processed_data = process_telemetry_data(file_path)
    
    if processed_data is not None:
        processed_data.replace({True: "Alert", False: "Normal"}, inplace=True)
        
        download_path = os.path.join(os.getcwd(), 'processed_telemetry_data.xlsx')
        processed_data.to_excel(download_path, index=False, engine='openpyxl')
        
        send_email(download_path)
        
        return send_file(download_path, as_attachment=True)
    else:
        return "Error processing data for download"


@app.route('/generate_pdf')
def generate_pdf_route():
    file_path = r'C:\Users\MOHANAPRASAD\Downloads\Maha.xlsx'
    processed_data = process_telemetry_data(file_path)
    if processed_data is not None:
        output_path = os.path.join(os.getcwd(), 'processed_telemetry_data.pdf')
        generate_pdf(processed_data, output_path)
        return send_file(output_path, as_attachment=True)
    else:
        return "Error processing data for PDF generation"

def generate_pdf(data, output_path):
    """
    Generate a PDF report from the given DataFrame, handling wide tables by splitting them into multiple pages.

    Args:
        data (DataFrame): The processed telemetry data.
        output_path (str): Path to save the generated PDF.
    """
    pdf = SimpleDocTemplate(output_path, pagesize=landscape(letter))
    elements = []
    columns_per_page = 10 
    total_columns = len(data.columns)
    num_pages = (total_columns + columns_per_page - 1) // columns_per_page

    for page_num in range(num_pages):
        start_col = page_num * columns_per_page
        end_col = min(start_col + columns_per_page, total_columns)

        # Slice data for the current page
        page_data = data.iloc[:, start_col:end_col]
        table_data = [list(page_data.columns)] + page_data.values.tolist()

        # Create table
        table = Table(table_data)

        # Apply styles
        style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.green),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ])
        table.setStyle(style)

        # Highlight anomalies
        for row_idx, row in enumerate(page_data.values, start=1):
            for col_idx, cell in enumerate(row):
                if isinstance(cell, bool):  # Convert True/False to Alert/Normal
                    value = "Alert" if cell else "Normal"
                    table_data[row_idx][col_idx] = value
                    if cell:  # True -> Alert (Red)
                        table.setStyle([
                            ('BACKGROUND', (col_idx, row_idx), (col_idx, row_idx), colors.red),
                            ('TEXTCOLOR', (col_idx, row_idx), (col_idx, row_idx), colors.whitesmoke),
                        ])
                    else:  # False -> Normal (Green)
                        table.setStyle([
                            ('BACKGROUND', (col_idx, row_idx), (col_idx, row_idx), colors.green),
                            ('TEXTCOLOR', (col_idx, row_idx), (col_idx, row_idx), colors.black),
                        ])

        elements.append(table)
        if page_num < num_pages - 1:  # Add page break if not the last page
            elements.append(PageBreak())

    # Build PDF
    pdf.build(elements)
    print(f"PDF report generated at {output_path}")


def send_email(file_path):
    email = EmailMessage()
    email["from"] = "bpraven05@gmail.com"
    email["to"] = "jaihari1020@gmail.com"
    email["subject"] = "Telemetry Report"
    email.set_content("Hello! Please find the attached telemetry report.")
    
    try:
        with open(file_path, "rb") as file:
            email.add_attachment(
                file.read(),
                maintype="application",
                subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                filename=os.path.basename(file_path),
            )
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return
    
    try:
        with smtplib.SMTP(host="smtp.gmail.com", port=587) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login("bpraven05@gmail.com", "dxew suoy yiex ozbx")  
            smtp.send_message(email)
        print("Email sent successfully!")
    except Exception as e:
        print(f"Error: Unable to send email. Details: {e}")

if __name__ == '__main__':
    app.run(debug=True)
