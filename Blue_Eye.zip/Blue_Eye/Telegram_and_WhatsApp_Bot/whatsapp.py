from twilio.rest import Client
import pandas as pd
ACCOUNT_SID = 'AC2965a5c179aa85915a79f231de4a8e50'
AUTH_TOKEN = 'd42589e41983d5a798f9671dfb942265' 
TWILIO_WHATSAPP_NUMBER = 'whatsapp:+14155238886'

client = Client(ACCOUNT_SID, AUTH_TOKEN)

RECIPIENT_NUMBER = 'whatsapp:+919444250633' 

def process_telemetry_data(file_path):
    try:
        df = pd.read_excel(file_path, engine='openpyxl')
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return None

    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

    df['water_level_anomaly'] = False
    df['battery_level_anomaly'] = False
    df['dwlr_depth_anomaly'] = False
    df['well_depth_anomaly'] = False
    df['temp_anomaly'] = False
    df['Notify'] = False

    for idx, row in df.iterrows():
        telemetry_uid = row['telemetry_uid']
        latitude = row['latitude']
        longitude = row['longitude']
        timestamp = row['timestamp']
        water_level = row['water_level']
        battery = row['battery']
        DWLR_depth = row['DWLR_depth']
        well_depth = row['well_depth']
        water_temperature = row['water_temperature']
        water_level_anomaly = False
        if not pd.isna(water_level):
            water_levels = df[df['telemetry_uid'] == row['telemetry_uid']]['water_level'].dropna()
            water_level_indices = water_levels.index.tolist()
            current_index = water_level_indices.index(row.name) 
            if current_index > 0:
                recent = water_levels.iloc[current_index]
                historical = water_levels.iloc[current_index - 1]
                diff = abs(recent - historical)
                water_level_anomaly = diff >= 0.35
            if water_level_anomaly:
                return (f'⚠️ Water Anomaly Detected! Telemetry ID: {telemetry_uid}, Timestamp: {timestamp}, Spike of {diff} metre, Location: https://www.google.com/maps?q={latitude},{longitude}')



        battery_level_anomaly = False
        if not pd.isna(battery):
            battery_level_anomaly = not (3.25 <= battery <= 4)
            if battery_level_anomaly:
                return (f'⚠️ Battery Anomaly Detected! Telemetry ID: {telemetry_uid}, Timestamp: {timestamp}, Battery Level: {battery}%, Location: https://www.google.com/maps?q={latitude},{longitude}')


        dwlr_depth_anomaly = False
        if not pd.isna(DWLR_depth) and abs(water_level) > DWLR_depth:
            dwlr_depth_anomaly = True
            if dwlr_depth_anomaly:
                return (f'⚠️ Incorrect reading! water level: {water_level} is greater than the depth of DWLR: {DWLR_depth}, Telemetry ID: {telemetry_uid}, Timestamp: {timestamp}, Location: https://www.google.com/maps?q={latitude},{longitude}')

        well_depth_anomaly = False
        if not pd.isna(well_depth) and (DWLR_depth > well_depth or abs(water_level) > well_depth):
            well_depth_anomaly = True
            if well_depth_anomaly:
                return (f'⚠️ Incorrect reading! Depth of DWLR: {DWLR_depth} is greater than the Well depth: {well_depth}, Telemetry ID: {telemetry_uid}, Timestamp: {timestamp}, Location: https://www.google.com/maps?q={latitude},{longitude}')

       
        temp_anomaly = False
        if not pd.isna(water_temperature):
            temp_anomaly = not (15 <= water_temperature <= 35)
            if temp_anomaly:
                return (f'⚠️ Abnormal temperature detected! Temperature: {water_temperature}, Telemetry ID: {telemetry_uid}, Timestamp: {timestamp}, Location: https://www.google.com/maps?q={latitude},{longitude}  ')
        
        notify = any([water_level_anomaly, battery_level_anomaly, dwlr_depth_anomaly, well_depth_anomaly, temp_anomaly])


def send_whatsapp_message(to_number, message_body):
    try:
        message = client.messages.create(
            from_=TWILIO_WHATSAPP_NUMBER,
            body=message_body,
            to=to_number
        )
        print(f"Message sent to {to_number}: {message_body}")
        return message.sid
    except Exception as e:
        print(f"Failed to send message to {to_number}: {e}")
        return None

def main():
    file_path = r'C:\Users\MOHANAPRASAD\Downloads\Maha.xlsx'
    message_body = process_telemetry_data(file_path)
    send_whatsapp_message(RECIPIENT_NUMBER, message_body)

if __name__ == '__main__':
    main()
