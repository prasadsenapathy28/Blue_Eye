import re
import json

def convert_to_proper_json(json_like_str):
    # Use regex to add quotes around the keys
    corrected_json_str = re.sub(r'(\w+)\s*:', r'"\1":', json_like_str)
    # Convert the corrected string to a JSON object
    json_obj = json.loads(corrected_json_str)
    return json_obj

# Example input
json_like_str = """ 
"West Bengal": {
        Alipurduar: {
            AlipurduarI: [
            "dwlr_wb_001",
            "dwlr_wb_002"
            ],
            AlipurduarIi: [
            "dwlr_wb_003",
            "dwlr_wb_004"
            ],
            Falakata: [
            "dwlr_wb_005",
            "dwlr_wb_006",
            "dwlr_wb_007"
            ],
            Kalchini: [
            "dwlr_wb_008",
            "dwlr_wb_009",
            "dwlr_wb_010",
            "dwlr_wb_011",
            "dwlr_wb_012"
            ],
            Kumargram: [
            "dwlr_wb_013",
            "dwlr_wb_014",
            "dwlr_wb_015",
            "dwlr_wb_016",
            "dwlr_wb_017",
            "dwlr_wb_018",
            "dwlr_wb_019",
            "dwlr_wb_020"
            ],
            Madarihat: [
            "dwlr_wb_021",
            "dwlr_wb_022",
            "dwlr_wb_023"
            ]
        },
        Bankura: {
            BankuraI: [
            "dwlr_wb_024",
            "dwlr_wb_025",
            "dwlr_wb_026",
            "dwlr_wb_027"
            ],
            BankuraIi: [
            "dwlr_wb_028",
            "dwlr_wb_029",
            "dwlr_wb_030",
            "dwlr_wb_031",
            "dwlr_wb_032",
            "dwlr_wb_033",
            "dwlr_wb_034"
            ],
            Barjora: [
            "dwlr_wb_035",
            "dwlr_wb_036",
            "dwlr_wb_037",
            "dwlr_wb_038",
            "dwlr_wb_039"
            ],
            Bishnupur: [
            "dwlr_wb_040",
            "dwlr_wb_041",
            "dwlr_wb_042",
            "dwlr_wb_043",
            "dwlr_wb_044",
            "dwlr_wb_045",
            "dwlr_wb_046",
            "dwlr_wb_047",
            "dwlr_wb_048",
            "dwlr_wb_049",
            "dwlr_wb_050",
            "dwlr_wb_051",
            "dwlr_wb_052",
            "dwlr_wb_053",
            "dwlr_wb_054"
            ],
            RaipurI: [
            "dwlr_wb_055"
            ],
            RaipurIi: [
            "dwlr_wb_056",
            "dwlr_wb_057"
            ],
            Ranibandh: [
            "dwlr_wb_058",
            "dwlr_wb_059",
            "dwlr_wb_060",
            "dwlr_wb_061",
            "dwlr_wb_062",
            "dwlr_wb_063"
            ],
            Saltora: [
            "dwlr_wb_064",
            "dwlr_wb_065",
            "dwlr_wb_066",
            "dwlr_wb_067",
            "dwlr_wb_068",
            "dwlr_wb_069",
            "dwlr_wb_070"
            ],
            Simlapal: [
            "dwlr_wb_071",
            "dwlr_wb_072"
            ],
            Simlipal: [
            "dwlr_wb_073"
            ],
            Sonamukhi: [
            "dwlr_wb_074",
            "dwlr_wb_075",
            "dwlr_wb_076",
            "dwlr_wb_077",
            "dwlr_wb_078",
            "dwlr_wb_079",
            "dwlr_wb_080",
            "dwlr_wb_081"
            ],
            Taldanga: [
            "dwlr_wb_082",
            "dwlr_wb_083",
            "dwlr_wb_084",
            "dwlr_wb_085"
            ],
            Taldangra: [
            "dwlr_wb_086",
            "dwlr_wb_087",
            "dwlr_wb_088"
            ]
        },
        Birbhum: {
            Bolpur: [
            "dwlr_wb_089",
            "dwlr_wb_090",
            "dwlr_wb_091",
            "dwlr_wb_092",
            "dwlr_wb_093",
            "dwlr_wb_094",
            "dwlr_wb_095",
            "dwlr_wb_096",
            "dwlr_wb_097",
            "dwlr_wb_098",
            "dwlr_wb_099",
            "dwlr_wb_100",
            "dwlr_wb_101",
            "dwlr_wb_102",
            "dwlr_wb_103"
            ],
            Dubrajpur: [
            "dwlr_wb_104",
            "dwlr_wb_105",
            "dwlr_wb_106",
            "dwlr_wb_107",
            "dwlr_wb_108",
            "dwlr_wb_109",
            "dwlr_wb_110",
            "dwlr_wb_111",
            "dwlr_wb_112",
            "dwlr_wb_113"
            ],
            Nalhati: [
            "dwlr_wb_114",
            "dwlr_wb_115",
            "dwlr_wb_116",
            "dwlr_wb_117"
            ],
            Rajnagar: [
            "dwlr_wb_118",
            "dwlr_wb_119",
            "dwlr_wb_120"
            ],
            Rampurhat: [
            "dwlr_wb_121",
            "dwlr_wb_122",
            "dwlr_wb_123"
            ],
            RampurhatI: [
            "dwlr_wb_124",
            "dwlr_wb_125",
            "dwlr_wb_126",
            "dwlr_wb_127",
            "dwlr_wb_128",
            "dwlr_wb_129",
            "dwlr_wb_130"
            ],
            Sainthia: [
            "dwlr_wb_131",
            "dwlr_wb_132"
            ],
            SiuriI: [
            "dwlr_wb_133"
            ],
            Sriniketan: [
            "dwlr_wb_134",
            "dwlr_wb_135",
            "dwlr_wb_136"
            ],
            SuriIi: [
            "dwlr_wb_137",
            "dwlr_wb_142",
            "dwlr_wb_143",
            "dwlr_wb_144",
            "dwlr_wb_145",
            "dwlr_wb_146",
            "dwlr_wb_147"
            ],
            SuriI: [
            "dwlr_wb_138",
            "dwlr_wb_139",
            "dwlr_wb_140",
            "dwlr_wb_141"
            ]
        },
        CoochBihar: {
            Sitai: [
            "dwlr_wb_148"
            ]
        },
        DakshinDinajpur: {
            Balurghat: [
            "dwlr_wb_149"
            ],
            Bansihari: [
            "dwlr_wb_150"
            ],
            Gangarampur: [
            "dwlr_wb_151"
            ],
            Harirampur: [
            "dwlr_wb_152"
            ],
            Hili: [
            "dwlr_wb_153",
            "dwlr_wb_154"
            ],
            Kumarganj: [
            "dwlr_wb_155"
            ],
            Tapan: [
            "dwlr_wb_156",
            "dwlr_wb_157",
            "dwlr_wb_158",
            "dwlr_wb_159",
            "dwlr_wb_160",
            "dwlr_wb_161"
            ]
        },
        Darjeeling: {
            Kharibari: [
            "dwlr_wb_162",
            "dwlr_wb_163",
            "dwlr_wb_164",
            "dwlr_wb_165",
            "dwlr_wb_166",
            "dwlr_wb_167",
            "dwlr_wb_168",
            "dwlr_wb_169",
            "dwlr_wb_170",
            "dwlr_wb_171"
            ]
        },
        Hugli: {
            Balagarh: [
            "dwlr_wb_172",
            "dwlr_wb_173"
            ],
            Chinsura: [
            "dwlr_wb_174"
            ],
            Chuchura: [
            "dwlr_wb_175"
            ],
            Haripal: [
            "dwlr_wb_176"
            ],
            Jirat: [
            "dwlr_wb_177"
            ],
            Magra: [
            "dwlr_wb_178"
            ],
            Pandua: [
            "dwlr_wb_179",
            "dwlr_wb_180",
            "dwlr_wb_181"
            ],
            Polba: [
            "dwlr_wb_182",
            "dwlr_wb_183",
            "dwlr_wb_184"
            ],
            Sherpur: [
            "dwlr_wb_185"
            ],
            Srirampur: [
            "dwlr_wb_186",
            "dwlr_wb_187"
            ],
            Tarakeswar: [
            "dwlr_wb_188"
            ]
        },
        Jalpaiguri: {
            Dhupguri: [
            "dwlr_wb_189",
            "dwlr_wb_190",
            "dwlr_wb_191",
            "dwlr_wb_192",
            "dwlr_wb_193",
            "dwlr_wb_194",
            "dwlr_wb_195"
            ],
            Jalpaiguri: [
            "dwlr_wb_196",
            "dwlr_wb_197",
            "dwlr_wb_198",
            "dwlr_wb_199",
            "dwlr_wb_200",
            "dwlr_wb_201",
            "dwlr_wb_202",
            "dwlr_wb_203",
            "dwlr_wb_204",
            "dwlr_wb_205"
            ],
            Mal: [
            "dwlr_wb_206",
            "dwlr_wb_207",
            "dwlr_wb_208",
            "dwlr_wb_209"
            ],
            Malbazar: [
            "dwlr_wb_210",
            "dwlr_wb_211"
            ],
            Mangalghat: [
            "dwlr_wb_212"
            ],
            Matiali: [
            "dwlr_wb_213",
            "dwlr_wb_214",
            "dwlr_wb_215"
            ],
            Maynaguri: [
            "dwlr_wb_216",
            "dwlr_wb_217",
            "dwlr_wb_218",
            "dwlr_wb_219",
            "dwlr_wb_220"
            ],
            Moynaguri: [
            "dwlr_wb_221",
            "dwlr_wb_222",
            "dwlr_wb_223"
            ],
            Nagrakata: [
            "dwlr_wb_224"
            ]
        },
        Kochbehar: {
            MathabhangaI: [
            "dwlr_wb_225",
            "dwlr_wb_226"
            ],
            MathabhangaIi: [
            "dwlr_wb_227"
            ],
            Mekhliganj: [
            "dwlr_wb_228",
            "dwlr_wb_229",
            "dwlr_wb_230",
            "dwlr_wb_231",
            "dwlr_wb_232"
            ],
            Sahebgan: [
            "dwlr_wb_233"
            ],
            Sitai: [
            "dwlr_wb_234"
            ],
            Sitalkuchi: [
            "dwlr_wb_235",
            "dwlr_wb_236"
            ],
            Tufanganj: [
            "dwlr_wb_237",
            "dwlr_wb_238",
            "dwlr_wb_239"
            ],
            TufanganjIi: [
            "dwlr_wb_240",
            "dwlr_wb_241",
            "dwlr_wb_242"
            ]
        },
        Malda: {
            Bamangola: [
            "dwlr_wb_243",
            "dwlr_wb_244",
            "dwlr_wb_245"
            ],
            Bamongola: [
            "dwlr_wb_246",
            "dwlr_wb_247",
            "dwlr_wb_248"
            ],
            EnglishBazar: [
            "dwlr_wb_249",
            "dwlr_wb_250",
            "dwlr_wb_251",
            "dwlr_wb_252"
            ],
            Gazole: [
            "dwlr_wb_253",
            "dwlr_wb_254",
            "dwlr_wb_255",
            "dwlr_wb_256",
            "dwlr_wb_257",
            "dwlr_wb_258",
            "dwlr_wb_259",
            "dwlr_wb_260"
            ],
            Gazol: [
            "dwlr_wb_261"
            ],
            Habibpur: [
            "dwlr_wb_262",
            "dwlr_wb_263"
            ],
            KaliachakI: [
            "dwlr_wb_264",
            "dwlr_wb_265"
            ],
            KaliachakIii: [
            "dwlr_wb_266"
            ],
            Malda: [
            "dwlr_wb_267"
            ],
            Manikchak: [
            "dwlr_wb_268",
            "dwlr_wb_269",
            "dwlr_wb_270"
            ],
            OldMalda: [
            "dwlr_wb_271"
            ],
            RatuaI: [
            "dwlr_wb_272",
            "dwlr_wb_273",
            "dwlr_wb_274"
            ]
        },
        Murshidabad: {
            BeldangaI: [
            "dwlr_wb_275",
            "dwlr_wb_277"
            ],
            Beldangai: [
            "dwlr_wb_276"
            ],
            Domkal: [
            "dwlr_wb_278",
            "dwlr_wb_279",
            "dwlr_wb_280"
            ],
            KarimpurI: [
            "dwlr_wb_281",
            "dwlr_wb_282"
            ],
            KarimpurII: [
            "dwlr_wb_283",
            "dwlr_wb_284"
            ],
            Krishnanagar: [
            "dwlr_wb_285"
            ]
        },
        Howrah: {
            Deulia: [
            "dwlr_wb_286"
            ],
            Narayanpur: [
            "dwlr_wb_287"
            ],
            Shibpur: [
            "dwlr_wb_288"
            ],
            Shyampur: [
            "dwlr_wb_289"
            ]
        },
        "chim Barddhaman": {
            "ansol": [
            "dwlr_wb_290"
            ],
            Barabani: [
            "dwlr_wb_291"
            ],
            Baraboni: [
            "dwlr_wb_292",
            "dwlr_wb_293"
            ],
            Durgapur: [
            "dwlr_wb_294",
            "dwlr_wb_295",
            "dwlr_wb_296",
            "dwlr_wb_297",
            "dwlr_wb_298",
            "dwlr_wb_299"
            ],
            Hirapur: [
            "dwlr_wb_300"
            ],
            Jamuria: [
            "dwlr_wb_301"
            ],
            JamuriaI: [
            "dwlr_wb_302",
            "dwlr_wb_303",
            "dwlr_wb_304"
            ],
            JamuriaIi: [
            "dwlr_wb_305",
            "dwlr_wb_306",
            "dwlr_wb_307",
            "dwlr_wb_308",
            "dwlr_wb_309"
            ],
            Kanksa: [
            "dwlr_wb_310",
            "dwlr_wb_311",
            "dwlr_wb_312",
            "dwlr_wb_313",
            "dwlr_wb_314",
            "dwlr_wb_315",
            "dwlr_wb_316"
            ],
            Kanska: [
            "dwlr_wb_317"
            ],
            Kulti: [
            "dwlr_wb_318",
            "dwlr_wb_319",
            "dwlr_wb_320",
            "dwlr_wb_321",
            "dwlr_wb_322",
            "dwlr_wb_323"
            ],
            Raniganj: [
            "dwlr_wb_324",
            "dwlr_wb_325"
            ],
            Salanpur: [
            "dwlr_wb_326",
            "dwlr_wb_327",
            "dwlr_wb_328",
            "dwlr_wb_329",
            "dwlr_wb_330",
            "dwlr_wb_331",
            "dwlr_wb_332",
            "dwlr_wb_333"
            ]
        },
        PurbaBarddhaman: {
            Ausgram: [
            "dwlr_wb_334"
            ],
            AusgramI: [
            "dwlr_wb_335"
            ],
            AusgramIi: [
            "dwlr_wb_336"
            ],
            BarddhamanSadar: [
            "dwlr_wb_337"
            ],
            Bardhaman: [
            "dwlr_wb_338"
            ],
            Bhatar: [
            "dwlr_wb_339"
            ],
            Ekangarsarai: [
            "dwlr_wb_340",
            "dwlr_wb_341"
            ],
            Kanksha: [
            "dwlr_wb_342"
            ],
            Katwa: [
            "dwlr_wb_343",
            "dwlr_wb_344"
            ],
            Mukutmanipur: [
            "dwlr_wb_345"
            ],
            Raipur: [
            "dwlr_wb_346"
            ],
            Sriniketan: [
            "dwlr_wb_347",
            "dwlr_wb_348",
            "dwlr_wb_349"
            ],
            Vorada: [
            "dwlr_wb_350"
            ]
        },
        Purulia: {
            Barabazar: [
            "dwlr_wb_351",
            "dwlr_wb_352"
            ],
            Bundwan: [
            "dwlr_wb_353"
            ],
            Hura: [
            "dwlr_wb_354",
            "dwlr_wb_355",
            "dwlr_wb_356",
            "dwlr_wb_357",
            "dwlr_wb_358",
            "dwlr_wb_359",
            "dwlr_wb_360",
            "dwlr_wb_361"
            ]
        }
    }
"""

# Convert the input and print the output
proper_json = convert_to_proper_json(json_like_str)
print(json.dumps(proper_json, indent=2))