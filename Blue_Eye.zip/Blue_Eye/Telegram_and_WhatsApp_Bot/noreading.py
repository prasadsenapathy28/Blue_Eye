import pandas as pd
from flask import Flask, render_template_string

app = Flask(__name__)

def process_telemetry_data(file_path):
    # Read the Excel file
    try:
        df = pd.read_excel(file_path, engine='openpyxl')
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return None

    # Ensure 'timestamp' is treated as a datetime
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

    # Group by DWLR ID and then by date
    processed_data = []
    grouped_by_dwlr = df.groupby('telemetry_uid')

    for dwlr_id, dwlr_group in grouped_by_dwlr:
        grouped_by_date = dwlr_group.groupby(dwlr_group['timestamp'].dt.date)

        for date, group in grouped_by_date:
            # Calculate missed times
            required_times = ["00:00:00", "06:00:00", "12:00:00", "18:00:00"]
            times_available = group['timestamp'].dt.strftime('%H:%M:%S').unique()
            missed_times = len([time for time in required_times if time not in times_available])

            # Calculate null values count
            null_values_count = group.isnull().sum().sum()

            # Check water level anomaly
            water_levels = group['water_level'].dropna()
            water_level_anomaly = False
            if len(water_levels) > 1:
                diff = abs(water_levels.iloc[-1] - water_levels.iloc[0])
                water_level_anomaly = diff >= 0.30

            # Check most recent battery level anomaly
            battery_levels = group['battery'].dropna()
            battery_levels.index = pd.to_datetime(battery_levels.index)

            # Find the most recent battery level
            most_recent_battery_level = battery_levels.idxmax()  # Get the timestamp with the max value
            last_battery_level = battery_levels.loc[most_recent_battery_level]
            battery_level_anomaly = not (3.25 <= last_battery_level <= 4)

            notify = water_level_anomaly or battery_level_anomaly

            # Add to processed data
            processed_data.append({
                'DWLR ID': dwlr_id,
                'Date': date,
                'Times per Day Missed': missed_times,
                'Null Values': null_values_count,
                'Water Level Anomaly': water_level_anomaly,
                'Battery Level Anomaly': battery_level_anomaly,
                'Notify': notify
            })

    return processed_data

def data_to_html(data):
    # Generate HTML for all data combined into a single table
    html = '''
    <html>
    <head>
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }
            table, th, td {
                border: 1px solid black;
            }
            th, td {
                padding: 8px;
                text-align: center;
            }
            th {
                background-color: #4CAF50;
                color: white;
            }
            td.water-level-anomaly {
                background-color: #FFC0CB;
            }
            td.battery-level-anomaly {
                background-color: #FFB6C1;
            }
            td.notify-true {
                background-color: #FFFF00;
            }
        </style>
    </head>
    <body>
        <h1>Processed Telemetry Data</h1>
        <table>
            <tr>
                <th>DWLR ID</th>
                <th>Date</th>
                <th>Times per Day Missed</th>
                <th>Null Values</th>
                <th class="water-level-anomaly">Water Level Anomaly</th>
                <th class="battery-level-anomaly">Battery Level Anomaly</th>
                <th class="notify-true">Notify</th>
            </tr>'''
    for row in data:
        html += '<tr>'
        for key, value in row.items():
            if isinstance(value, bool):
                class_name = "notify-true" if value else ""
            elif key == 'Water Level Anomaly':
                class_name = "water-level-anomaly" if value else ""
            elif key == 'Battery Level Anomaly':
                class_name = "battery-level-anomaly" if value else ""
            else:
                class_name = ""
            html += f'<td class="{class_name}">{value}</td>'
        html += '</tr>'

    html += '</table></body></html>'
    return html

@app.route('/')
def display_table():
    file_path = r'C:\Users\MOHANAPRASAD\Downloads\Maha.xlsx'
    processed_data = process_telemetry_data(file_path)
    if processed_data:
        return render_template_string(data_to_html(processed_data))
    else:
        return "Error processing data"

if __name__ == '__main__':
    app.run(debug=True)